const express = require('express');
const bodyParser = require('body-parser');
const crypto = require('crypto');
const { encrypt, decrypt } = require('./encryptionModule');

const app = express();
const port = 3000;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/index.html');
});

app.post('/encrypt', (req, res) => {
  const plaintext = req.body.text;

  try {
    if (!plaintext) {
      throw new Error('Text is undefined or empty.');
    }

    const encryptedText = encrypt(plaintext);
    res.send({ result: encryptedText });
  } catch (error) {
    console.error('Encryption error:', error.message);
    res.status(500).send({ error: 'Encryption failed.' });
  }
});

app.post('/decrypt', (req, res) => {
  const encryptedText = req.body.text;

  try {
    if (!encryptedText) {
      throw new Error('Text is undefined or empty.');
    }

    const decryptedText = decrypt(encryptedText);
    res.send({ result: decryptedText });
  } catch (error) {
    console.error('Decryption error:', error.message);
    res.status(500).send({ error: 'Decryption failed.' });
  }
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});

