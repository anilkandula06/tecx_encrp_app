'use strict';

const crypto = require('crypto');

let ENCRYPTION_KEY;

// Set the encryption key if it's not already set
if (!process.env.ENCRYPTION_KEY) {
  ENCRYPTION_KEY = crypto.randomBytes(32).toString('hex');
  console.log('Generated new encryption key:', ENCRYPTION_KEY);
} else {
  ENCRYPTION_KEY = process.env.ENCRYPTION_KEY;
}

const IV_LENGTH = 16;

function encrypt(text) {
  try {
    if (!text) {
      throw new Error('Text is undefined or empty.');
    }

    const iv = crypto.randomBytes(IV_LENGTH);
    const cipher = crypto.createCipheriv('aes-256-cbc', Buffer.from(ENCRYPTION_KEY, 'hex'), iv);
    let encrypted = cipher.update(text, 'utf-8', 'hex');
    encrypted += cipher.final('hex');

    return iv.toString('hex') + ':' + encrypted;
  } catch (error) {
    console.error('Encryption error:', error.message);
    throw error;
  }
}

function decrypt(text) {
  try {
    if (!text) {
      throw new Error('Text is undefined or empty.');
    }

    const textParts = text.split(':');
    const iv = Buffer.from(textParts.shift(), 'hex');
    const encryptedText = Buffer.from(textParts.join(':'), 'hex');
    const decipher = crypto.createDecipheriv('aes-256-cbc', Buffer.from(ENCRYPTION_KEY, 'hex'), iv);
    let decrypted = decipher.update(encryptedText, 'hex', 'utf-8');
    decrypted += decipher.final('utf-8');

    return decrypted;
  } catch (error) {
    console.error('Decryption error:', error.message);
    throw error;
  }
}

module.exports = { decrypt, encrypt };

